import { useState } from 'react';
export default function AIPlanner(){
  const [prompt,setPrompt]=useState('Generate 10 Roblox short ideas about Steal a Brainrot');
  const [output,setOutput]=useState('');
  const run=async()=>{ setOutput('AI placeholder — paste your OpenAI key and implement server call.'); }
  return (<div style={{padding:20}}>
    <h1>AI Content Planner</h1>
    <textarea rows={4} value={prompt} onChange={e=>setPrompt(e.target.value)} />
    <br/><button onClick={run}>Run</button>
    <pre>{output}</pre>
  </div>)
}
