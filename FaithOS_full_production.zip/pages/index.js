import Link from 'next/link'
import allocations from '../data/allocations.json'
export default function Home(){
  const total = allocations.reduce((s,a)=>s+a.allocated_amount,0)
  const spent = allocations.reduce((s,a)=>s+a.spent_amount,0)
  const remaining = total - spent
  return (
    <div className="container">
      <header className="topbar"><div className="logo">GK</div><nav><Link href='/content'>Content</Link> | <Link href='/investments'>Investments</Link> | <Link href='/crm'>CRM</Link></nav></header>
      <main>
        <section className="card">
          <h2>Daily Verse</h2>
          <p id="daily-verse">"Be still and know that I am God."</p>
          <small>Theme: ROTATING</small>
        </section>
        <section className="card">
          <h3>Quick Metrics</h3>
          <div>Subscribers: <strong>110,000</strong></div>
          <div>Total Capital: <strong>${total}</strong></div>
          <div>Remaining Capital: <strong>${remaining}</strong></div>
        </section>
      </main>
    </div>
  )
}
