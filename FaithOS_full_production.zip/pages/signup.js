import { useState } from 'react';
import { auth } from '../lib/firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
export default function Signup(){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const signup=async()=>{ try{ await createUserWithEmailAndPassword(auth,email,password); window.location.href='/'; }catch(e){ alert(e.message)} }
  return (<div style={{padding:20}}><h1>Signup</h1><input placeholder='email' onChange={e=>setEmail(e.target.value)} /><br/><input placeholder='password' type='password' onChange={e=>setPassword(e.target.value)} /><br/><button onClick={signup}>Sign up</button></div>)
}
