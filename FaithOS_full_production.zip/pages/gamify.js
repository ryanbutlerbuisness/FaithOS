import { useEffect, useState } from 'react';
import { db } from '../lib/firebase';
import { doc, getDoc, setDoc, updateDoc, increment } from 'firebase/firestore';
export default function Gamify(){
  const [xp,setXp]=useState(0);
  useEffect(()=>{ async function load(){ const ref=doc(db,'gamify','user_ryan'); const snap=await getDoc(ref); if(snap.exists()) setXp(snap.data().xp || 0); else await setDoc(ref,{xp:0}); } load(); },[]);
  const add=async()=>{ const ref=doc(db,'gamify','user_ryan'); await updateDoc(ref,{xp:increment(50)}); const snap=await getDoc(ref); setXp(snap.data().xp); }
  return (<div style={{padding:20}}><h1>Gamification</h1><div>XP: {xp}</div><button onClick={add}>+50 XP (simulate publish)</button></div>)
}
