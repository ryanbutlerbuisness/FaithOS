import allocations from '../data/allocations.json'
import { compoundGrowth, requiredMonthlyContribution, timeToGoal } from '../lib/invest'
import { useState } from 'react'
export default function Investments(){
  const total = allocations.reduce((s,a)=>s+a.allocated_amount,0)
  const spent = allocations.reduce((s,a)=>s+a.spent_amount,0)
  const remaining = total - spent
  const [start,setStart]=useState(13000), [monthly,setMonthly]=useState(0), [rate,setRate]=useState(10), [years,setYears]=useState(5), [target,setTarget]=useState(5000)
  return (<div style={{padding:20}}>
    <h1>Investments</h1>
    <div>Total Capital: ${total}</div>
    <div>Remaining: ${remaining}</div>
    <div style={{marginTop:20}}>
      <h3>Investment Tools</h3>
      <input placeholder="start" value={start} onChange={e=>setStart(+e.target.value)} />
      <input placeholder="monthly" value={monthly} onChange={e=>setMonthly(+e.target.value)} />
      <input placeholder="rate" value={rate} onChange={e=>setRate(+e.target.value)} />
      <input placeholder="years" value={years} onChange={e=>setYears(+e.target.value)} />
      <div>Future: ${compoundGrowth(start, monthly, rate/100, years)}</div>
      <div>Time to $target: {timeToGoal(start, monthly, rate/100, target)} years</div>
    </div>
  </div>)
}
