import { useEffect, useState } from 'react';
import { db } from '../lib/firebase';
import { collection, addDoc, getDocs } from 'firebase/firestore';
export default function Content(){
  const [items,setItems]=useState([]); const [title,setTitle]=useState('');
  useEffect(()=>{ async function load(){ const snap=await getDocs(collection(db,'content')); setItems(snap.docs.map(d=>({id:d.id,...d.data()}))); } load(); },[]);
  const add=async()=>{ await addDoc(collection(db,'content'),{title}); setTitle(''); alert('Added'); }
  return (<div style={{padding:20}}>
    <h1>Content Pipeline</h1>
    <input placeholder="title" value={title} onChange={e=>setTitle(e.target.value)} />
    <button onClick={add}>Add</button>
    <ul>{items.map(i=>(<li key={i.id}>{i.title}</li>))}</ul>
  </div>)
}
