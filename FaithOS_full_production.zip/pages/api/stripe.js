export default async function handler(req,res){
  res.status(200).json({message:'Stripe endpoint placeholder. Add server-side Stripe secret and implement Checkout session.'});
}
