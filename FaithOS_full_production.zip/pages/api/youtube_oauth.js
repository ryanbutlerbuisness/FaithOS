export default async function handler(req,res){
  res.status(200).json({message:'YouTube OAuth placeholder. Implement OAuth server flow with Google Cloud credentials.'});
}
