FAITHOS FULL PRODUCTION SCAFFOLD
Generated: 2025-12-12T00:24:11.063133Z

This bundle is a developer-ready scaffold for FaithOS containing:
- Next.js + Tailwind frontend scaffold
- Firebase auth + Firestore CRUD placeholders
- Next.js API route placeholders for Stripe + YouTube OAuth
- Gamification module (Firestore-based)
- Expo React Native app scaffold (basic)
- AI Planner page placeholder
- Seed data in /data

IMPORTANT: This is a scaffold. Replace env variables and complete provider keys to enable full functionality.

ENVIRONMENT VARIABLES (.env.local):
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=
FIREBASE_ADMIN_PRIVATE_KEY= (for server side if used)
STRIPE_SECRET_KEY=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
GOOGLE_OAUTH_CLIENT_ID=
GOOGLE_OAUTH_CLIENT_SECRET=
OPENAI_API_KEY=

HOW TO RUN (local):
1. npm install
2. Create .env.local with the keys above
3. npm run dev
4. Open http://localhost:3000

DEPLOY:
- Push to GitHub and deploy on Vercel
- Set environment variables in Vercel project settings
